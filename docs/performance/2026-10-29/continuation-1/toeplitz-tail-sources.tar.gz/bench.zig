const std = @import("std");
const k = @import("kuznechik.zig");
const gfni = @import("gfni.zig");
const toeplitz = @import("toeplitz.zig");
const core = @import("toeplitz_core.zig");
const transitions = @import("transitions.zig");
const B = k.block;
const Policy = enum { matrix, toeplitz_fresh, toeplitz_prepared };
const policies = [_]Policy{ .matrix, .toeplitz_fresh, .toeplitz_prepared };
const max_samples = 31;

inline fn matrixBatch(comptime inverse: bool, comptime width: usize, cipher: *const k.Cipher, messages: *align(16) [width]B) void {
    if (inverse) gfni.decrypt(width / 4, &cipher.ik, messages) else gfni.encrypt(width / 4, &cipher.ik, messages);
}
inline fn matrixPadded(comptime inverse: bool, comptime width: usize, cipher: *const k.Cipher, messages: []align(16) B) void {
    if (messages.len == width) return matrixBatch(inverse, width, cipher, messages[0..width]);
    var padded: [width]B align(16) = @splat(@as(B, @splat(0)));
    @memcpy(padded[0..messages.len], messages);
    matrixBatch(inverse, width, cipher, &padded);
    @memcpy(messages, padded[0..messages.len]);
}
noinline fn apply(comptime policy: Policy, comptime inverse: bool, cipher: *const k.Cipher, prepared: *const [10]B, messages: []align(16) B) void {
    if (policy == .matrix) {
        inline for (.{ 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64 }) |width| {
            if (messages.len <= width) return matrixPadded(inverse, width, cipher, messages);
        }
        unreachable;
    }
    var padded: [64]B align(16) = @splat(@as(B, @splat(0)));
    @memcpy(padded[0..messages.len], messages);
    if (policy == .toeplitz_fresh) {
        const encoded = toeplitz.prepareKeys(if (inverse) &cipher.ik_inv else &cipher.ik, inverse);
        if (inverse) toeplitz.decryptPrepared(&cipher.ik, &encoded, &padded) else toeplitz.encryptPrepared(&encoded, &padded);
    } else {
        if (inverse) toeplitz.decryptPrepared(&cipher.ik, prepared, &padded) else toeplitz.encryptPrepared(prepared, &padded);
    }
    @memcpy(messages, padded[0..messages.len]);
}
noinline fn run(comptime policy: Policy, comptime inverse: bool, cipher: *const k.Cipher, prepared: *const [10]B, messages: []align(16) B, loops: usize) void {
    for (0..loops) |_| apply(policy, inverse, cipher, prepared, messages);
    std.mem.doNotOptimizeAway(messages);
}
fn checksum(messages: []const B) u64 {
    var h: u64 = 0;
    for (std.mem.sliceAsBytes(messages)) |b| h = h *% 65537 +% b;
    return h;
}
fn reference(comptime inverse: bool, cipher: *const k.Cipher, msg: B) B {
    var x = msg;
    if (inverse) {
        for (0..9) |r| x = transitions.s_inv_trans(transitions.l_inv_trans(x ^ cipher.ik[9-r]));
    } else {
        for (0..9) |r| x = transitions.l_trans(transitions.s_trans(x ^ cipher.ik[r]));
    }
    return x ^ cipher.ik[if (inverse) 0 else 9];
}
fn validate(random: std.Random) !void {
    try toeplitz.selftest();
    for (0..16) |position| for (0..8) |bit| {
        var unit: [16]u8 = @splat(0);
        unit[position] = @as(u8, 1) << @intCast(bit);
        var a: [16]u8 = undefined;
        var b: [16]u8 = undefined;
        for (0..16) |i| {
            a[i] = mul(unit[i], core.column_inverse[i]);
            b[i] = mul(unit[i], core.column_inverse[15-i]);
        }
        a = core.forward(u8, a);
        b = core.inverse(u8, b);
        const forward = transitions.l_trans(@as(B, unit));
        const inverse = transitions.l_inv_trans(@as(B, unit));
        for (0..16) |i| {
            if (mul(a[i], core.row_inverse[i]) != forward[i]) return error.LinearMismatch;
            if (mul(b[i], core.row_inverse[15-i]) != inverse[i]) return error.InverseLinearMismatch;
        }
    };
    for (0..4) |_| {
        var key: k.key = undefined;
        random.bytes(std.mem.asBytes(&key));
        const cipher = k.Cipher.init(key);
        inline for (.{ false, true }) |inverse| {
            const ek = toeplitz.prepareKeys(if (inverse) &cipher.ik_inv else &cipher.ik, inverse);
            for (2..64) |length| {
                var input: [66]B align(64) = undefined;
                random.bytes(std.mem.asBytes(&input));
                var expected = input;
                for (expected[1..][0..length]) |*m| m.* = reference(inverse, &cipher, m.*);
                inline for (policies) |policy| {
                    var actual = input;
                    apply(policy, inverse, &cipher, &ek, actual[1..][0..length]);
                    if (!std.mem.eql(u8, std.mem.asBytes(&expected), std.mem.asBytes(&actual))) return error.DifferentialOrCanaryMismatch;
                }
            }
        }
    }
    std.debug.print("{{\"type\":\"validation\",\"passed\":true,\"random_keys\":4,\"lengths\":62,\"directions\":2,\"policies\":3,\"every_byte_sbox_key_check\":true,\"linear_basis_vectors\":128,\"canaries\":true}}\n", .{});
}
fn mul(a_in: u8, b_in: u8) u8 {
    var a = a_in;
    var b = b_in;
    var out: u8 = 0;
    for (0..8) |_| {
        if (b & 1 != 0) out ^= a;
        a = (a << 1) ^ @as(u8, if (a & 128 != 0) 0xc3 else 0);
        b >>= 1;
    }
    return out;
}
pub fn main() !void {
    if (!gfni.supported) return error.UnsupportedTarget;
    const args = try std.process.argsAlloc(std.heap.page_allocator);
    defer std.process.argsFree(std.heap.page_allocator, args);
    const start = if (args.len > 1) try std.fmt.parseInt(usize, args[1], 0) else 2;
    const end = if (args.len > 2) try std.fmt.parseInt(usize, args[2], 0) else 63;
    const samples = if (args.len > 3) try std.fmt.parseInt(usize, args[3], 0) else 15;
    const loops = if (args.len > 4) try std.fmt.parseInt(usize, args[4], 0) else 15000;
    const seed = if (args.len > 5) try std.fmt.parseInt(u64, args[5], 0) else 0x746f65707461696c;
    if (start < 2 or end > 63 or end < start or samples == 0 or samples > max_samples or loops == 0) return error.InvalidConfig;
    var prng = std.Random.DefaultPrng.init(seed);
    const random = prng.random();
    try validate(random);
    std.debug.print("{{\"type\":\"config\",\"seed\":{d},\"start\":{d},\"end\":{d},\"samples\":{d},\"calls_per_sample\":{d},\"cpu\":\"{s}\",\"memory_clobber\":true,\"policy_order\":[\"matrix\",\"toeplitz_fresh\",\"toeplitz_prepared\"]}}\n", .{ seed, start, end, samples, loops, @import("builtin").cpu.model.name });
    inline for (.{ false, true }) |inverse| {
        for (start..end+1) |length| {
            var key: k.key = undefined;
            random.bytes(std.mem.asBytes(&key));
            const cipher = k.Cipher.init(key);
            const ek = toeplitz.prepareKeys(if (inverse) &cipher.ik_inv else &cipher.ik, inverse);
            var input: [66]B align(64) = undefined;
            random.bytes(std.mem.asBytes(&input));
            var times: [3][max_samples]u64 = undefined;
            var hashes: [3]u64 = .{0} ** 3;
            inline for (policies) |policy| {
                var warm = input;
                run(policy, inverse, &cipher, &ek, warm[1..][0..length], @max(1, loops/10));
            }
            for (0..samples) |sample| {
                var buffers: [3][66]B align(64) = .{input} ** 3;
                for (0..3) |slot| {
                    const index = if (sample % 2 == 0) (slot + sample) % 3 else (2-slot + sample) % 3;
                    inline for (policies, 0..) |policy, j| if (j == index) {
                        const buffer_index = (j + sample) % 3;
                        var timer = try std.time.Timer.start();
                        run(policy, inverse, &cipher, &ek, buffers[buffer_index][1..][0..length], loops);
                        times[j][sample] = timer.read();
                        hashes[j] +%= checksum(buffers[buffer_index][1..][0..length]);
                    };
                }
            }
            if (hashes[0] != hashes[1] or hashes[0] != hashes[2]) return error.TimingChecksumMismatch;
            std.debug.print("{{\"type\":\"result\",\"decrypt\":{s},\"length\":{d},\"matrix_width\":{d},\"calls\":{d},\"checksum\":{d},\"elapsed_ns\":[", .{ if (inverse) "true" else "false", length, ((length+3)/4)*4, loops, hashes[0] });
            for (times, 0..) |t, i| {
                std.debug.print("{s}[", .{if (i == 0) "" else ","});
                for (t[0..samples], 0..) |v, j| std.debug.print("{s}{d}", .{ if (j == 0) "" else ",", v });
                std.debug.print("]", .{});
            }
            std.debug.print("]}}\n", .{});
        }
    }
}
