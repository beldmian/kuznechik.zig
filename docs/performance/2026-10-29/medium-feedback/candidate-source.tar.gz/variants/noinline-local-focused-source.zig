//! Allocation-free byte interfaces. ECB/CBC use complete blocks without padding.
const std = @import("std");
const B = @Vector(16, u8);
fn load(bytes: *const [16]u8) B {
    return bytes.*;
}
fn store(bytes: *[16]u8, value: B) void {
    bytes.* = value;
}
fn xorBytes(data: []u8, stream: []const u8) void {
    for (data, stream[0..data.len]) |*byte, mask| byte.* ^= mask;
}

pub fn Modes(comptime Cipher: type) type {
    return struct {
        pub fn ecbEncrypt(cipher: *const Cipher, data: []u8) !void {
            try ecb(false, cipher, data);
        }
        pub fn ecbDecrypt(cipher: *const Cipher, data: []u8) !void {
            try ecb(true, cipher, data);
        }
        fn ecb(comptime inverse: bool, cipher: *const Cipher, data: []u8) !void {
            if (data.len % 16 != 0) return error.InvalidLength;
            if (data.len == 0) return;
            if (@intFromPtr(data.ptr) % 16 == 0) {
                const blocks: [*]align(16) B = @ptrCast(@alignCast(data.ptr));
                if (inverse) cipher.decryptBlocks(blocks[0 .. data.len / 16]) else cipher.encryptBlocks(blocks[0 .. data.len / 16]);
                return;
            }
            var at: usize = 0;
            while (at < data.len) {
                const count: usize = @min(64, (data.len - at) / 16);
                var blocks: [64]B = undefined;
                for (0..count) |i| blocks[i] = load(data[at + i * 16 ..][0..16]);
                if (inverse) cipher.decryptBlocks(blocks[0..count]) else cipher.encryptBlocks(blocks[0..count]);
                for (0..count) |i| store(data[at + i * 16 ..][0..16], blocks[i]);
                at += count * 16;
            }
        }

        pub const Ctr = CtrWithCounter(64);
        pub fn CtrWithCounter(comptime counter_bits: u7) type {
            if (counter_bits < 32 or counter_bits > 96 or counter_bits % 8 != 0) @compileError("CTR counter must be32..96 bits in whole bytes");
            return struct {
                const Self = @This();
                pub const Nonce = [(@as(usize, 128) - counter_bits) / 8]u8;
                cipher: Cipher,
                prefix: u128,
                blocks: u128 = 0,
                stream: B = @splat(0),
                used: usize = 16,
                pub fn init(cipher: Cipher, nonce: Nonce) Self {
                    var value: [16]u8 = @splat(0);
                    @memcpy(value[0..nonce.len], &nonce);
                    return .{ .cipher = cipher, .prefix = std.mem.readInt(u128, &value, .big) };
                }
                pub fn xor(self: *Self, data: []u8) error{CounterExhausted}!void {
                    const available = 16 - self.used;
                    const missing = data.len - @min(available, data.len);
                    const needed: u128 = @as(u128, missing) / 16 + @intFromBool(missing % 16 != 0);
                    const limit = @as(u128, 1) << (counter_bits - 1);
                    if (self.blocks > limit or needed > limit - self.blocks) return error.CounterExhausted;
                    var at: usize = 0;
                    if (self.used < 16) {
                        const n = @min(available, data.len);
                        const bytes: [16]u8 = self.stream;
                        xorBytes(data[0..n], bytes[self.used..]);
                        self.used += n;
                        at = n;
                    }
                    while (data.len - at >= 16) {
                        const count: usize = @min(64, (data.len - at) / 16);
                        var counters: [64]B = undefined;
                        for (0..count) |i| {
                            var bytes: [16]u8 = undefined;
                            std.mem.writeInt(u128, &bytes, self.prefix | (self.blocks + i), .big);
                            counters[i] = bytes;
                        }
                        self.cipher.encryptBlocks(counters[0..count]);
                        for (0..count) |i| store(data[at + i * 16 ..][0..16], load(data[at + i * 16 ..][0..16]) ^ counters[i]);
                        self.blocks += count;
                        at += count * 16;
                    }
                    if (at < data.len) {
                        var bytes: [16]u8 = undefined;
                        std.mem.writeInt(u128, &bytes, self.prefix | self.blocks, .big);
                        self.stream = bytes;
                        self.cipher.encrypt(&self.stream);
                        self.blocks += 1;
                        const gamma: [16]u8 = self.stream;
                        self.used = data.len - at;
                        xorBytes(data[at..], &gamma);
                    }
                }
            };
        }

        pub fn Cbc(comptime iv_blocks: usize) type {
            if (iv_blocks == 0) @compileError("CBC IV must contain at least one block");
            return struct {
                const Self = @This();
                cipher: Cipher,
                register: [iv_blocks]B,
                head: usize = 0,
                pub fn init(cipher: Cipher, iv: [iv_blocks * 16]u8) Self {
                    var self = Self{ .cipher = cipher, .register = undefined };
                    for (0..iv_blocks) |i| self.register[i] = load(iv[i * 16 ..][0..16]);
                    return self;
                }
                pub fn encrypt(self: *Self, data: []u8) error{InvalidLength}!void {
                    if (data.len % 16 != 0) return error.InvalidLength;
                    if (iv_blocks >= 2 and data.len >= (if (iv_blocks == 2) @as(usize, 128) else if (iv_blocks == 3) @as(usize, 48) else 64)) return self.encryptBatched(data);
                    self.encryptScalar(data);
                }
                noinline fn encryptBatched(self: *Self, data: []u8) void {
                    var at: usize = 0;
                    while (data.len - at >= (if (iv_blocks == 3) @as(usize, 48) else 64)) {
                        // Until the ring repeats, each plaintext block depends
                        // only on a distinct entry of the existing register.
                        const count: usize = @min(64, iv_blocks, (data.len - at) / 16);
                        var blocks: [@min(64, iv_blocks)]B = undefined;
                        for (0..count) |i| blocks[i] = load(data[at + i * 16 ..][0..16]) ^ self.register[(self.head + i) % iv_blocks];
                        self.cipher.encryptBlocks(blocks[0..count]);
                        for (0..count) |i| {
                            store(data[at + i * 16 ..][0..16], blocks[i]);
                            self.register[(self.head + i) % iv_blocks] = blocks[i];
                        }
                        self.head = (self.head + count) % iv_blocks;
                        at += count * 16;
                    }
                    self.encryptScalar(data[at..]);
                }
                fn encryptScalar(self: *Self, data: []u8) void {
                    var at: usize = 0;
                    while (at < data.len) : (at += 16) {
                        var value = load(data[at..][0..16]) ^ self.register[self.head];
                        self.cipher.encrypt(&value);
                        store(data[at..][0..16], value);
                        self.register[self.head] = value;
                        self.head = (self.head + 1) % iv_blocks;
                    }
                }
                pub fn decrypt(self: *Self, data: []u8) error{InvalidLength}!void {
                    if (data.len % 16 != 0) return error.InvalidLength;
                    var at: usize = 0;
                    while (at < data.len) {
                        const count: usize = @min(64, (data.len - at) / 16);
                        var blocks: [64]B = undefined;
                        for (0..count) |i| blocks[i] = load(data[at + i * 16 ..][0..16]);
                        self.cipher.decryptBlocks(blocks[0..count]);
                        for (0..count) |i| {
                            const ct = load(data[at + i * 16 ..][0..16]);
                            store(data[at + i * 16 ..][0..16], blocks[i] ^ self.register[self.head]);
                            self.register[self.head] = ct;
                            self.head = (self.head + 1) % iv_blocks;
                        }
                        at += count * 16;
                    }
                }
            };
        }

        pub fn Cfb(comptime iv_blocks: usize) type {
            if (iv_blocks == 0) @compileError("CFB IV must contain at least one block");
            return struct {
                const Self = @This();
                cipher: Cipher,
                register: [iv_blocks]B,
                head: usize = 0,
                used: usize = 16,
                stream: B = @splat(0),
                feedback: [16]u8 = @splat(0),
                pub fn init(cipher: Cipher, iv: [iv_blocks * 16]u8) Self {
                    var self = Self{ .cipher = cipher, .register = undefined };
                    for (0..iv_blocks) |i| self.register[i] = load(iv[i * 16 ..][0..16]);
                    return self;
                }
                pub fn encrypt(self: *Self, data: []u8) void {
                    // Independent lanes also exist in small feedback registers.
                    // Keep irregular large registers on their measured scalar path.
                    if ((iv_blocks >= 2 and iv_blocks < 64 or iv_blocks >= 64 and std.math.isPowerOfTwo(iv_blocks)) and data.len >= (if (iv_blocks == 2) @as(usize, 128) else if (iv_blocks == 3) @as(usize, 48) else 64)) return self.encryptBatched(data);
                    if (comptime iv_blocks >= 2 and iv_blocks < 64) return self.encryptScalar(data);
                    self.crypt(false, data);
                }
                noinline fn encryptScalar(self: *Self, data: []u8) void {
                    self.crypt(false, data);
                }
                noinline fn encryptBatched(self: *Self, data: []u8) void {
                    var at: usize = 0;
                    if (self.used < 16) {
                        const n = @min(16 - self.used, data.len);
                        self.crypt(false, data[0..n]);
                        at = n;
                    }
                    while (data.len - at >= (if (iv_blocks == 3) @as(usize, 48) else 64)) {
                        const count: usize = @min(64, iv_blocks, (data.len - at) / 16);
                        var gamma: [@min(64, iv_blocks)]B = undefined;
                        for (0..count) |i| gamma[i] = self.register[(self.head + i) % iv_blocks];
                        self.cipher.encryptBlocks(gamma[0..count]);
                        for (0..count) |i| {
                            const ct = load(data[at + i * 16 ..][0..16]) ^ gamma[i];
                            store(data[at + i * 16 ..][0..16], ct);
                            self.register[(self.head + i) % iv_blocks] = ct;
                        }
                        // These fields remain observable after a complete block
                        // and must match the scalar encryption path exactly.
                        self.stream = gamma[count - 1];
                        self.feedback = data[at + (count - 1) * 16 ..][0..16].*;
                        self.head = (self.head + count) % iv_blocks;
                        at += count * 16;
                    }
                    self.crypt(false, data[at..]);
                }
                pub fn decrypt(self: *Self, data: []u8) void {
                    self.crypt(true, data);
                }
                fn crypt(self: *Self, comptime inverse: bool, data: []u8) void {
                    var at: usize = 0;
                    while (at < data.len) {
                        if (inverse and self.used == 16 and data.len - at >= 16) {
                            const count: usize = @min(64, (data.len - at) / 16);
                            var gamma: [64]B = undefined;
                            for (0..count) |i| gamma[i] = if (i < iv_blocks) self.register[(self.head + i) % iv_blocks] else load(data[at + (i - iv_blocks) * 16 ..][0..16]);
                            self.cipher.encryptBlocks(gamma[0..count]);
                            for (0..count) |i| {
                                const ct = load(data[at + i * 16 ..][0..16]);
                                store(data[at + i * 16 ..][0..16], ct ^ gamma[i]);
                                self.register[self.head] = ct;
                                self.head = (self.head + 1) % iv_blocks;
                            }
                            at += count * 16;
                            continue;
                        }
                        if (self.used == 16) {
                            self.stream = self.register[self.head];
                            self.cipher.encrypt(&self.stream);
                            self.used = 0;
                        }
                        const n = @min(16 - self.used, data.len - at);
                        const gamma: [16]u8 = self.stream;
                        for (0..n) |i| {
                            const input = data[at + i];
                            const output = input ^ gamma[self.used + i];
                            self.feedback[self.used + i] = if (inverse) input else output;
                            data[at + i] = output;
                        }
                        self.used += n;
                        at += n;
                        if (self.used == 16) {
                            self.register[self.head] = self.feedback;
                            self.head = (self.head + 1) % iv_blocks;
                        }
                    }
                }
            };
        }

        pub fn Ofb(comptime iv_blocks: usize) type {
            if (iv_blocks == 0) @compileError("OFB IV must contain at least one block");
            return struct {
                const Self = @This();
                cipher: Cipher,
                register: [iv_blocks]B,
                head: usize = 0,
                used: usize = 16,
                stream: B = @splat(0),
                pub fn init(cipher: Cipher, iv: [iv_blocks * 16]u8) Self {
                    var self = Self{ .cipher = cipher, .register = undefined };
                    for (0..iv_blocks) |i| self.register[i] = load(iv[i * 16 ..][0..16]);
                    return self;
                }
                pub fn xor(self: *Self, data: []u8) void {
                    if (iv_blocks >= 64 and data.len >= 64) return self.xorBatched(data);
                    self.xorScalar(data);
                }
                fn xorScalar(self: *Self, data: []u8) void {
                    var at: usize = 0;
                    while (at < data.len) {
                        if (self.used == 16) {
                            if (self.head == 0) self.cipher.encryptBlocks(&self.register);
                            self.stream = self.register[self.head];
                            self.head = (self.head + 1) % iv_blocks;
                            self.used = 0;
                        }
                        const n = @min(16 - self.used, data.len - at);
                        const gamma: [16]u8 = self.stream;
                        xorBytes(data[at..][0..n], gamma[self.used..]);
                        self.used += n;
                        at += n;
                    }
                }
                fn xorBatched(self: *Self, data: []u8) void {
                    var at: usize = 0;
                    while (at < data.len) {
                        if (self.used == 16) {
                            if (self.head == 0) self.cipher.encryptBlocks(&self.register);
                            // Amortize ring bookkeeping only for larger IVs. Small
                            // rings keep the measured existing path.
                            if (iv_blocks >= 64 and data.len - at >= 64) {
                                const count: usize = @min(iv_blocks - self.head, (data.len - at) / 16);
                                if (count >= 4) {
                                    for (0..count) |i| {
                                        const gamma = self.register[self.head + i];
                                        store(data[at + i * 16 ..][0..16], load(data[at + i * 16 ..][0..16]) ^ gamma);
                                    }
                                    self.stream = self.register[self.head + count - 1];
                                    self.head = (self.head + count) % iv_blocks;
                                    at += count * 16;
                                    continue;
                                }
                            }
                            self.stream = self.register[self.head];
                            self.head = (self.head + 1) % iv_blocks;
                            self.used = 0;
                        }
                        const n = @min(16 - self.used, data.len - at);
                        const gamma: [16]u8 = self.stream;
                        xorBytes(data[at..][0..n], gamma[self.used..]);
                        self.used += n;
                        at += n;
                    }
                }
            };
        }

        pub const Cmac = struct {
            const Self = @This();
            cipher: Cipher,
            state: B = @splat(0),
            pending: [16]u8 = @splat(0),
            used: usize = 0,
            k1: B,
            k2: B,
            pub fn init(cipher: Cipher) Self {
                var l: B = @splat(0);
                cipher.encrypt(&l);
                const k1 = double(l);
                return .{ .cipher = cipher, .k1 = k1, .k2 = double(k1) };
            }
            pub fn update(self: *Self, input: []const u8) void {
                var data = input;
                while (data.len > 0) {
                    if (self.used == 16) {
                        self.state ^= load(&self.pending);
                        self.cipher.encrypt(&self.state);
                        self.used = 0;
                    }
                    const n = @min(16 - self.used, data.len);
                    @memcpy(self.pending[self.used..][0..n], data[0..n]);
                    self.used += n;
                    data = data[n..];
                }
            }
            pub fn final(self: Self) [16]u8 {
                var last = self.pending;
                if (self.used < 16) {
                    @memset(last[self.used..], 0);
                    last[self.used] = 0x80;
                }
                var tag = self.state ^ load(&last) ^ (if (self.used == 16) self.k1 else self.k2);
                self.cipher.encrypt(&tag);
                return tag;
            }
            pub fn verify(self: Self, tag: []const u8) !void {
                if (tag.len == 0 or tag.len > 16) return error.InvalidTagLength;
                const full = self.final();
                var expected: [16]u8 = @splat(0);
                var actual: [16]u8 = @splat(0);
                @memcpy(expected[0..tag.len], full[0..tag.len]);
                @memcpy(actual[0..tag.len], tag);
                if (!std.crypto.timing_safe.eql([16]u8, expected, actual)) return error.AuthenticationFailed;
            }
            fn double(value: B) B {
                var bytes: [16]u8 = value;
                const n = std.mem.readInt(u128, &bytes, .big);
                std.mem.writeInt(u128, &bytes, (n << 1) ^ (@as(u128, 0x87) * (n >> 127)), .big);
                return bytes;
            }
        };
    };
}

test "RFC3602 CBC and RFC4493 CMAC vectors using the generic construction" {
    const h = @import("test_helpers.zig");
    const testing = std.testing;
    const M = Modes(h.Aes128);
    const cipher = h.Aes128.init(h.hex("06a9214036b8a15b512e03d534120006"));
    const iv = h.hex("3dafba429d9eb430b422da802c9fac41");
    var message = "Single block msg".*;
    var enc = M.Cbc(1).init(cipher, iv);
    try enc.encrypt(&message);
    try testing.expectEqualSlices(u8, &h.hex("e353779c1079aeb82708942dbe77181a"), &message);
    var dec = M.Cbc(1).init(cipher, iv);
    try dec.decrypt(&message);
    try testing.expectEqualSlices(u8, "Single block msg", &message);
    const mac_cipher = h.Aes128.init(h.hex("2b7e151628aed2a6abf7158809cf4f3c"));
    const data = h.hex("6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710");
    inline for (.{ 0, 16, 40, 64 }, .{ "bb1d6929e95937287fa37d129b756746", "070a16b46b4d4144f79bdd9dd04a287c", "dfa66747de9ae63030ca32611497c827", "51f0bebf7e3b9d92fc49741779363cfe" }) |n, tag| {
        var mac = M.Cmac.init(mac_cipher);
        mac.update(data[0..n]);
        try testing.expectEqual(h.hex(tag), mac.final());
        const valid_tag = mac.final();
        try mac.verify(&valid_tag);
        var invalid_tag = valid_tag;
        invalid_tag[0] ^= 1;
        try testing.expectError(error.AuthenticationFailed, mac.verify(&invalid_tag));
        try testing.expectError(error.InvalidTagLength, mac.verify(&.{}));
        var split = M.Cmac.init(mac_cipher);
        for (data[0..n]) |byte| split.update(&.{byte});
        try testing.expectEqual(mac.final(), split.final());
    }
}

test "RFC8645 CTR base vectors and counter exhaustion preserve input" {
    const h = @import("test_helpers.zig");
    const testing = std.testing;
    const cipher = h.Aes256.init(h.hex("8899aabbccddeeff0011223344556677fedcba98765432100123456789abcdef"));
    const M = Modes(h.Aes256);
    var ctr = M.Ctr.init(cipher, h.hex("1234567890abcef0"));
    var zeros: [32]u8 = @splat(0);
    try ctr.xor(&zeros);
    try testing.expectEqual(h.hex("fd7ef89ad97ea4b88db8b51c1c9d6dd01998c5717637fb1711e448f00c0d60b2"), zeros);
    var exhausted = M.CtrWithCounter(32).init(cipher, @splat(0));
    exhausted.blocks = (@as(u128, 1) << 31) - 1;
    var one = [_]u8{0};
    try exhausted.xor(&one);
    var rest: [15]u8 = @splat(0);
    try exhausted.xor(&rest);
    var rejected = [_]u8{42};
    try testing.expectError(error.CounterExhausted, exhausted.xor(&rejected));
    try testing.expectEqual(@as(u8, 42), rejected[0]);
}

test "NIST800-38A ECB CBC CFB128 and OFB known-answer vectors" {
    const h = @import("test_helpers.zig");
    const testing = std.testing;
    const M = Modes(h.Aes128);
    const c = h.Aes128.init(h.hex("2b7e151628aed2a6abf7158809cf4f3c"));
    const iv = h.hex("000102030405060708090a0b0c0d0e0f");
    const plain = h.hex("6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710");
    var ecb = plain;
    try M.ecbEncrypt(&c, &ecb);
    try testing.expectEqual(h.hex("3ad77bb40d7a3660a89ecaf32466ef97f5d3d58503b9699de785895a96fdbaaf43b1cd7f598ece23881b00e3ed0306887b0c785e27e8ad3f8223207104725dd4"), ecb);
    var cbc = plain;
    var cb = M.Cbc(1).init(c, iv);
    try cb.encrypt(&cbc);
    try testing.expectEqual(h.hex("7649abac8119b246cee98e9b12e9197d5086cb9b507219ee95db113a917678b273bed6b8e3c1743b7116e69e222295163ff1caa1681fac09120eca307586e1a7"), cbc);
    var cfb = plain;
    var cf = M.Cfb(1).init(c, iv);
    cf.encrypt(&cfb);
    try testing.expectEqual(h.hex("3b3fd92eb72dad20333449f8e83cfb4ac8a64537a0b3a93fcde3cdad9f1ce58b26751f67a3cbb140b1808cf187a4f4dfc04b05357c5d1c0eeac4c66f9ff7f2e6"), cfb);
    var ofb = plain;
    var of = M.Ofb(1).init(c, iv);
    of.xor(&ofb);
    try testing.expectEqual(h.hex("3b3fd92eb72dad20333449f8e83cfb4a7789508d16918f03f53c52dac54ed8259740051e9c5fecf64344f7a82260edcc304c6528f659c77866a510d9c1d6ae5e"), ofb);
}

test "Kuznechik classic modes preserve streaming and feedback across batch boundaries" {
    const C = @import("../kuznechik.zig").Cipher;
    const M = Modes(C);
    const testing = std.testing;
    var rng = std.Random.DefaultPrng.init(0x5246434d4f444553);
    const random = rng.random();
    var key: @Vector(32, u8) = undefined;
    random.bytes(std.mem.asBytes(&key));
    const cipher = C.init(key);
    var plain: [1057]u8 = undefined;
    random.bytes(&plain);
    var nonce: [8]u8 = undefined;
    random.bytes(&nonce);
    var reference = plain;
    var counter: usize = 0;
    var at: usize = 0;
    while (at < plain.len) : (counter += 1) {
        var input: [16]u8 = @splat(0);
        @memcpy(input[0..8], &nonce);
        std.mem.writeInt(u64, input[8..16], @intCast(counter), .big);
        var gamma: B = input;
        cipher.encrypt(&gamma);
        const bytes: [16]u8 = gamma;
        const n = @min(16, plain.len - at);
        xorBytes(reference[at..][0..n], &bytes);
        at += n;
    }
    var actual = plain;
    var ctr = M.Ctr.init(cipher, nonce);
    try ctr.xor(&actual);
    try testing.expectEqualSlices(u8, &reference, &actual);
    var split = plain;
    var ctr_split = M.Ctr.init(cipher, nonce);
    for (&split) |*byte| try ctr_split.xor(@as(*[1]u8, @ptrCast(byte)));
    try testing.expectEqualSlices(u8, &actual, &split);
    inline for (.{ 1, 2, 3 }) |width| {
        var iv: [width * 16]u8 = undefined;
        random.bytes(&iv);
        var cfb = plain;
        var cfb_ctx = M.Cfb(width).init(cipher, iv);
        cfb_ctx.encrypt(&cfb);
        var cfb_split = plain;
        var cs = M.Cfb(width).init(cipher, iv);
        at = 0;
        while (at < plain.len) {
            const n = @min((at % 37) + 1, plain.len - at);
            cs.encrypt(cfb_split[at..][0..n]);
            at += n;
        }
        try testing.expectEqualSlices(u8, &cfb, &cfb_split);
        var cd = M.Cfb(width).init(cipher, iv);
        cd.decrypt(&cfb);
        try testing.expectEqualSlices(u8, &plain, &cfb);
        var cds = M.Cfb(width).init(cipher, iv);
        for (&cfb_split) |*byte| cds.decrypt(@as(*[1]u8, @ptrCast(byte)));
        try testing.expectEqualSlices(u8, &plain, &cfb_split);
        var ofb = plain;
        var os = M.Ofb(width).init(cipher, iv);
        os.xor(&ofb);
        var ofb_split = plain;
        var oss = M.Ofb(width).init(cipher, iv);
        for (&ofb_split) |*byte| oss.xor(@as(*[1]u8, @ptrCast(byte)));
        try testing.expectEqualSlices(u8, &ofb, &ofb_split);
        var od = M.Ofb(width).init(cipher, iv);
        od.xor(&ofb);
        try testing.expectEqualSlices(u8, &plain, &ofb);
        var cbc = plain[0..1056].*;
        var cb = M.Cbc(width).init(cipher, iv);
        try cb.encrypt(&cbc);
        var cbc_split = plain[0..1056].*;
        var cbs = M.Cbc(width).init(cipher, iv);
        for (0..66) |i| try cbs.encrypt(cbc_split[i * 16 ..][0..16]);
        try testing.expectEqualSlices(u8, &cbc, &cbc_split);
        var cdec = M.Cbc(width).init(cipher, iv);
        try cdec.decrypt(&cbc);
        try testing.expectEqualSlices(u8, plain[0..1056], &cbc);
        var invalid = [_]u8{11} ** 15;
        const before = invalid;
        try testing.expectError(error.InvalidLength, cb.encrypt(&invalid));
        try testing.expectEqual(before, invalid);
    }
    var ecb = plain[0..1056].*;
    try M.ecbEncrypt(&cipher, &ecb);
    try M.ecbDecrypt(&cipher, &ecb);
    try testing.expectEqualSlices(u8, plain[0..1056], &ecb);
    for (0..16) |offset| {
        var guarded: [1088]u8 align(16) = @splat(0xa5);
        @memcpy(guarded[offset..][0..1056], plain[0..1056]);
        const expected = guarded;
        try M.ecbEncrypt(&cipher, guarded[offset..][0..1056]);
        try M.ecbDecrypt(&cipher, guarded[offset..][0..1056]);
        try testing.expectEqual(expected, guarded);
    }
}

// These references deliberately use a physical byte shift register and a
// one-shot MAC, independently of the streaming/ring/full-block implementations.
fn feedbackReference(comptime C: type, comptime width: usize, cipher: C, iv: [width * 16]u8, data: []u8, comptime ofb: bool) void {
    var register = iv;
    var gamma: B = undefined;
    var feedback: [16]u8 = undefined;
    for (data, 0..) |*byte, i| {
        const pos = i % 16;
        if (pos == 0) {
            gamma = load(register[0..16]);
            cipher.encrypt(&gamma);
        }
        const stream: [16]u8 = gamma;
        byte.* ^= stream[pos];
        feedback[pos] = if (ofb) stream[pos] else byte.*;
        if (pos == 15) {
            std.mem.copyForwards(u8, register[0 .. register.len - 16], register[16..]);
            @memcpy(register[register.len - 16 ..], &feedback);
        }
    }
}

fn macReference(comptime C: type, cipher: C, data: []const u8) [16]u8 {
    var l: B = @splat(0);
    cipher.encrypt(&l);
    var subkey: [16]u8 = l;
    // Byte-wise big-endian GF doubling; no u128 or production double helper.
    var keys: [2][16]u8 = undefined;
    for (&keys) |*key| {
        const carry = subkey[0] >> 7;
        for (0..15) |i| subkey[i] = (subkey[i] << 1) | (subkey[i + 1] >> 7);
        subkey[15] = (subkey[15] << 1) ^ (@as(u8, 0x87) * carry);
        key.* = subkey;
    }
    var state: B = @splat(0);
    var at: usize = 0;
    while (data.len - at > 16) : (at += 16) {
        state ^= load(data[at..][0..16]);
        cipher.encrypt(&state);
    }
    const n = data.len - at;
    var last: [16]u8 = @splat(0);
    @memcpy(last[0..n], data[at..]);
    if (n < 16) last[n] = 0x80;
    state ^= load(&last) ^ load(&keys[@intFromBool(n < 16)]);
    cipher.encrypt(&state);
    return state;
}

fn checkFeedback(comptime C: type, cipher: C) !void {
    const M = Modes(C);
    var rng = std.Random.DefaultPrng.init(0x4346424f46425245);
    const random = rng.random();
    var plain: [2097]u8 = undefined;
    random.bytes(&plain);
    inline for (.{ 1, 2, 3, 16, 64, 65 }) |width| {
        var iv: [width * 16]u8 = undefined;
        random.bytes(&iv);
        inline for (.{ false, true }) |ofb| {
            var expected = plain;
            feedbackReference(C, width, cipher, iv, &expected, ofb);
            // Every split in a short message, plus both sides of ring/batch
            // boundaries and a continuation after a long partial update.
            for (0..98) |case| {
                const split: usize = if (case <= 81) case else ([_]usize{ 127, 128, 129, 1023, 1024, 1025, 1039, 1040, 1041, 1055, 1056, 1057, 2079, 2080, 2081, 2097 })[case - 82];
                const n: usize = if (case <= 81) 81 else plain.len;
                const offset: usize = case % 16;
                var guarded: [2130]u8 align(16) = @splat(0xa5);
                const data = guarded[offset..][0..n];
                @memcpy(data, plain[0..n]);
                var ctx = if (ofb) M.Ofb(width).init(cipher, iv) else M.Cfb(width).init(cipher, iv);
                if (ofb) {
                    ctx.xor(data[0..split]);
                    ctx.xor(data[split..split]);
                    ctx.xor(data[split..]);
                } else {
                    ctx.encrypt(data[0..split]);
                    ctx.encrypt(data[split..split]);
                    ctx.encrypt(data[split..]);
                }
                try std.testing.expectEqualSlices(u8, expected[0..n], data);
                for (guarded[0..offset]) |b| try std.testing.expectEqual(@as(u8, 0xa5), b);
                for (guarded[offset + n ..]) |b| try std.testing.expectEqual(@as(u8, 0xa5), b);
                // Independent expected ciphertext also exercises the inverse,
                // including 65-block IVs exceeding the 64-block batch size.
                var inverse = if (ofb) M.Ofb(width).init(cipher, iv) else M.Cfb(width).init(cipher, iv);
                if (ofb) {
                    inverse.xor(data[0..split]);
                    inverse.xor(data[split..]);
                } else {
                    inverse.decrypt(data[0..split]);
                    inverse.decrypt(data[split..]);
                }
                try std.testing.expectEqualSlices(u8, plain[0..n], data);
            }
        }
    }
}

test "CFB and OFB match independent AES byte shift registers with unaligned guards and splits" {
    const h = @import("test_helpers.zig");
    try checkFeedback(h.Aes128, h.Aes128.init(@splat(0x39)));
}

test "CFB and OFB match independent Kuznechik byte shift registers including m65" {
    const C = @import("../kuznechik.zig").Cipher;
    try checkFeedback(C, C.init(@splat(0x71)));
}

fn checkMac(comptime C: type, cipher: C) !void {
    const M = Modes(C);
    var rng = std.Random.DefaultPrng.init(0x434d4143524546);
    var guarded: [2113]u8 align(16) = undefined;
    rng.random().bytes(&guarded);
    const original = guarded;
    for (0..88) |case| {
        const n: usize = if (case <= 81) case else ([_]usize{ 1024, 1025, 1040, 1041, 2080, 2081 })[case - 82];
        const data = guarded[case % 16 ..][0..n];
        const expected = macReference(C, cipher, data);
        var whole = M.Cmac.init(cipher);
        whole.update(data);
        try std.testing.expectEqual(expected, whole.final());
        var bytes = M.Cmac.init(cipher);
        for (data) |byte| bytes.update(&.{byte});
        try std.testing.expectEqual(expected, bytes.final());
        // All short splits, selected large splits. final() is a snapshot;
        // finalize a prefix repeatedly, then append without reinitializing.
        const cases = if (n <= 81) n + 1 else 50;
        for (0..cases) |i| {
            const split: usize = if (n <= 81) i else @min(n, if (i < 32) i else n - (i - 32));
            var ctx = M.Cmac.init(cipher);
            ctx.update(data[0..split]);
            const prefix = macReference(C, cipher, data[0..split]);
            try std.testing.expectEqual(prefix, ctx.final());
            try std.testing.expectEqual(prefix, ctx.final());
            ctx.update(data[split..split]);
            try std.testing.expectEqual(prefix, ctx.final());
            ctx.update(data[split..]);
            try std.testing.expectEqual(expected, ctx.final());
        }
    }
    try std.testing.expectEqual(original, guarded);
}

test "CMAC independent byte subkeys retain final block across splits snapshot final and append" {
    const h = @import("test_helpers.zig");
    const C = @import("../kuznechik.zig").Cipher;
    try checkMac(h.Aes128, h.Aes128.init(@splat(0x93)));
    try checkMac(C, C.init(@splat(0x72)));
}

// Deliberately uses a shifting byte register and single-block encryption, so
// neither circular indexing nor encryptBlocks is shared with the tested paths.
fn FeedbackEncryptionReference(comptime C: type, comptime width: usize, comptime cfb: bool) type {
    return struct {
        cipher: C,
        register: [width * 16]u8,
        stream: [16]u8 = @splat(0),
        feedback: [16]u8 = @splat(0),
        used: usize = 16,
        blocks: usize = 0,
        fn encrypt(self: *@This(), data: []u8) void {
            if (cfb) {
                for (data) |*byte| {
                    if (self.used == 16) {
                        var gamma: B = self.register[0..16].*;
                        self.cipher.encrypt(&gamma);
                        self.stream = gamma;
                        self.used = 0;
                    }
                    byte.* ^= self.stream[self.used];
                    self.feedback[self.used] = byte.*;
                    self.used += 1;
                    if (self.used == 16) self.shift(&self.feedback);
                }
            } else {
                var at: usize = 0;
                while (at < data.len) : (at += 16) {
                    var bytes: [16]u8 = undefined;
                    for (&bytes, self.register[0..16], data[at..][0..16]) |*out, r, p| out.* = r ^ p;
                    var value: B = bytes;
                    self.cipher.encrypt(&value);
                    bytes = value;
                    @memcpy(data[at..][0..16], &bytes);
                    self.shift(&bytes);
                }
            }
        }
        fn decrypt(self: *@This(), data: []u8) void {
            var at: usize = 0;
            while (at < data.len) {
                if (!cfb or (self.used == 16 and data.len - at >= 16)) {
                    const ct = data[at..][0..16].*;
                    var value: B = if (cfb) self.register[0..16].* else ct;
                    if (cfb) self.cipher.encrypt(&value) else self.cipher.decrypt(&value);
                    const bytes: [16]u8 = value;
                    for (data[at..][0..16], 0..) |*byte, i| byte.* = bytes[i] ^ (if (cfb) ct[i] else self.register[i]);
                    self.shift(&ct);
                    at += 16;
                } else {
                    if (self.used == 16) {
                        var gamma: B = self.register[0..16].*;
                        self.cipher.encrypt(&gamma);
                        self.stream = gamma;
                        self.used = 0;
                    }
                    const ct = data[at];
                    data[at] ^= self.stream[self.used];
                    self.feedback[self.used] = ct;
                    self.used += 1;
                    at += 1;
                    if (self.used == 16) self.shift(&self.feedback);
                }
            }
        }
        fn shift(self: *@This(), last: *const [16]u8) void {
            std.mem.copyForwards(u8, self.register[0 .. self.register.len - 16], self.register[16..]);
            @memcpy(self.register[self.register.len - 16 ..], last);
            self.blocks += 1;
        }
        fn check(self: *const @This(), actual: anytype) !void {
            try std.testing.expectEqual(self.blocks % width, actual.head);
            for (0..width) |i| {
                const bytes: [16]u8 = actual.register[(actual.head + i) % width];
                try std.testing.expectEqualSlices(u8, self.register[i * 16 ..][0..16], &bytes);
            }
            if (cfb) {
                const stream: [16]u8 = actual.stream;
                try std.testing.expectEqual(self.used, actual.used);
                try std.testing.expectEqual(self.stream, stream);
                try std.testing.expectEqual(self.feedback, actual.feedback);
            }
        }
    };
}

fn checkFeedbackEncryptionBatches(comptime C: type, cipher: C) !void {
    const M = Modes(C);
    var rng = std.Random.DefaultPrng.init(0x4241544348454e43);
    var plain: [4304]u8 = undefined;
    rng.random().bytes(&plain);
    inline for (.{ 1, 2, 3, 4, 8, 16, 24, 31, 32, 63, 64, 65, 128 }) |width| {
        var iv: [width * 16]u8 = undefined;
        rng.random().bytes(&iv);
        inline for (.{ false, true }) |cfb| {
            const Ref = FeedbackEncryptionReference(C, width, cfb);
            // Prefixes position the ring and partial feedback on both sides of
            // the dispatch, 64-block batch and IV65/128 wrap boundaries.
            for ([_]usize{ 0, 1, 15, 16, 17, 47, 48, 49, 63, 64, 65, 79, 80, 81, 111, 112, 127, 128, 129, 143, 144, 1007, 1008, 1023, 1024, 1025, 1039, 1040, 1041, 1055, 1056, 1057, 2032, 2047, 2048, 2049, 2063, 2064, 2065, width * 16 - 1, width * 16, width * 16 + 1, width * 32 - 16, width * 32, width * 32 + 1 }) |prefix| {
                if (!cfb and prefix % 16 != 0) continue;
                for (0..16) |offset| {
                    var guarded: [4336]u8 align(16) = @splat(0xa5);
                    const data = guarded[offset..][0..plain.len];
                    @memcpy(data, &plain);
                    var expected = plain;
                    var ref = Ref{ .cipher = cipher, .register = iv };
                    var ctx = if (cfb) M.Cfb(width).init(cipher, iv) else M.Cbc(width).init(cipher, iv);
                    // Four updates include an empty call, a long group crossing
                    // the ring twice, and a continuation after a partial tail.
                    const end: usize = if (cfb) 4183 else 4176;
                    const cuts = [_]usize{ 0, prefix, prefix, end, plain.len };
                    for (cuts[0 .. cuts.len - 1], cuts[1..]) |start, stop| {
                        if (cfb) ctx.encrypt(data[start..stop]) else try ctx.encrypt(data[start..stop]);
                        ref.encrypt(expected[start..stop]);
                        try std.testing.expectEqualSlices(u8, &expected, data);
                        try ref.check(ctx);
                        // Incomplete CBC calls must reject before touching
                        // either the output or any context field.
                        if (!cfb) {
                            const saved = ctx;
                            const saved_data = guarded;
                            try std.testing.expectError(error.InvalidLength, ctx.encrypt(data[0..65]));
                            try std.testing.expect(std.meta.eql(saved, ctx));
                            try std.testing.expectEqualSlices(u8, &saved_data, &guarded);
                        }
                    }
                    for (guarded[0..offset]) |b| try std.testing.expectEqual(@as(u8, 0xa5), b);
                    for (guarded[offset + data.len ..]) |b| try std.testing.expectEqual(@as(u8, 0xa5), b);
                    var inverse = if (cfb) M.Cfb(width).init(cipher, iv) else M.Cbc(width).init(cipher, iv);
                    for (cuts[0 .. cuts.len - 1], cuts[1..]) |start, stop| {
                        if (cfb) inverse.decrypt(data[start..stop]) else try inverse.decrypt(data[start..stop]);
                    }
                    try std.testing.expectEqualSlices(u8, &plain, data);
                }
            }
            // Changing direction exposes stale stream/feedback values left by
            // complete-block decryption. Compare a physical shift register,
            // full output, every ring entry and both partial fields after each
            // call, including empty calls and every buffer alignment.
            var mixed_ctx = if (cfb) M.Cfb(width).init(cipher, iv) else M.Cbc(width).init(cipher, iv);
            var mixed_ref = Ref{ .cipher = cipher, .register = iv };
            for (0..96) |step| {
                var guarded: [2192]u8 align(16) = undefined;
                rng.random().bytes(&guarded);
                var expected = guarded;
                const offset = step % 16;
                const lengths = [_]usize{ 0, 1, 15, 16, 17, 47, 48, 49, 63, 64, 65, 112, 127, 128, 129, 144, width * 16 - 1, width * 16, width * 16 + 1, 2112 };
                const length = lengths[step % lengths.len];
                const n = if (cfb) length else length / 16 * 16;
                const data = guarded[offset..][0..n];
                const reference = expected[offset..][0..n];
                if (step % 3 == 0) {
                    if (cfb) mixed_ctx.decrypt(data) else try mixed_ctx.decrypt(data);
                    mixed_ref.decrypt(reference);
                } else {
                    if (cfb) mixed_ctx.encrypt(data) else try mixed_ctx.encrypt(data);
                    mixed_ref.encrypt(reference);
                }
                try std.testing.expectEqualSlices(u8, &expected, &guarded);
                try mixed_ref.check(mixed_ctx);
            }
            if (cfb) {
                // Every possible pending partial block length, with long calls
                // immediately after it, followed by scalar byte continuations.
                for (1..16) |split| {
                    var data = plain;
                    var expected = plain;
                    var ctx = M.Cfb(width).init(cipher, iv);
                    var ref = Ref{ .cipher = cipher, .register = iv };
                    ctx.encrypt(data[0..split]);
                    ref.encrypt(expected[0..split]);
                    try ref.check(ctx);
                    ctx.encrypt(data[split..4183]);
                    ref.encrypt(expected[split..4183]);
                    try ref.check(ctx);
                    for (4183..data.len) |i| {
                        ctx.encrypt(data[i..][0..1]);
                        ref.encrypt(expected[i..][0..1]);
                        try ref.check(ctx);
                    }
                    try std.testing.expectEqualSlices(u8, &expected, &data);
                }
            }
        }
    }
}

test "CBC CFB AES independent encryption registers and exact context across small medium and large IV batches" {
    const h = @import("test_helpers.zig");
    try checkFeedbackEncryptionBatches(h.Aes128, h.Aes128.init(@splat(0x51)));
}

test "CBC CFB Kuznechik independent encryption registers and exact context across small medium and large IV batches" {
    const C = @import("../kuznechik.zig").Cipher;
    try std.testing.expectEqual(@as(usize, 352), @sizeOf(C));
    try checkFeedbackEncryptionBatches(C, C.init(@splat(0x61)));
}
