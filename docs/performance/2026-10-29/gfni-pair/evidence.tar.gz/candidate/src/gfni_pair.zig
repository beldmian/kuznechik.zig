//! Two-block GFNI matrix kernel. Exactly two defined 128-bit lanes.
//! Dispatch additionally requires Zen 5; the original GFNI gate is unchanged.
const definitions = @import("definitions.zig");
const transitions = @import("transitions.zig");
const B = definitions.block;
const W = @Vector(32, u8);
const gfni = @import("gfni.zig");
const toAes = gfni.toAes;
pub const supported = gfni.supported and
    @import("std").Target.x86.featureSetHasAll(@import("builtin").cpu.features, &.{.avx512vl});
const Z = @Vector(64, u8);
fn substitution(comptime inverse: bool) [4]Z {
    @setEvalBranchQuota(100000);
    var table: [256]u8 = undefined;
    for (0..256) |i| {
        const p = if (inverse) definitions.pi_inv_table[i] else definitions.pi_table[i];
        table[toAes(@intCast(i))] = toAes(p);
    }
    var out: [4]Z = undefined;
    for (0..4) |i| out[i] = table[i * 64 ..][0..64].*;
    return out;
}
fn diagonalColumns(comptime inverse: bool) [16]W {
    @setEvalBranchQuota(1000000);
    var basis_columns: [16]B = undefined;
    for (0..16) |i| {
        var v: B = @splat(0);
        v[i] = 1;
        basis_columns[i] = if (inverse) transitions.l_inv_trans(v) else transitions.l_trans(v);
    }
    var table: [16]W = undefined;
    for (0..16) |rotation| {
        for (0..32) |j| {
            const output = j % 16;
            table[rotation][j] = toAes(basis_columns[(output + rotation) % 16][output]);
        }
    }
    return table;
}
const enc_s = substitution(false);
const dec_s = substitution(true);
const enc_diag = diagonalColumns(false);
const dec_diag = diagonalColumns(true);

// PALIGNR rotates each 128-bit block independently; the coefficients are the
// corresponding cyclic diagonals of L. Rotation zero needs no instruction.
inline fn rotate(a: W, comptime i: usize) W {
    if (i == 0) return a;
    return asm ("vpalignr %[i], %[a], %[a], %[out]"
        : [out] "=v" (-> W),
        : [a] "v" (a),
          [i] "n" (i),
    );
}
inline fn affine(a: W, comptime inverse: bool) W {
    const matrix: @Vector(4, u64) = @splat(comptime gfni.affineMatrix(inverse));
    return asm ("vgf2p8affineqb $0, %[matrix], %[a], %[out]"
        : [out] "=v" (-> W),
        : [a] "v" (a),
          [matrix] "vm" (matrix),
    );
}
inline fn perm2Z(a: Z, idx: Z, b: Z) Z {
    return asm ("vpermi2b %[b], %[a], %[idx]"
        : [out] "=v" (-> Z),
        : [idx] "0" (idx),
          [a] "v" (a),
          [b] "vm" (b),
    );
}
inline fn sbox(a: W, comptime inverse: bool) W {
    const table = if (inverse) dec_s else enc_s;
    // Widen only substitution; both upper lanes are explicitly defined.
    const z: Z = @shuffle(u8, a, a, [_]i32{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 } ** 2);
    const lo = perm2Z(table[0], z, table[1]);
    const hi = perm2Z(table[2], z, table[3]);
    const out = @select(u8, z < @as(Z, @splat(128)), lo, hi);
    return @shuffle(u8, out, out, [_]i32{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 });
}
inline fn mul(a: W, b: W) W {
    return asm ("vgf2p8mulb %[b], %[a], %[out]"
        : [out] "=v" (-> W),
        : [a] "v" (a),
          [b] "vm" (b),
    );
}
inline fn linear(a: W, comptime inverse: bool) W {
    const table = if (inverse) dec_diag else enc_diag;
    var out: [16]W = undefined;
    inline for (0..16) |i| out[i] = mul(rotate(a, i), table[i]);
    inline for (.{ 1, 2, 4, 8 }) |step| {
        inline for (0..16 / (step * 2)) |j| {
            const i = j * step * 2;
            out[i] ^= out[i + step];
        }
    }
    return out[0];
}
inline fn broadcast(a: B) W {
    return @shuffle(u8, a, a, [_]i32{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 } ** 2);
}

pub fn encrypt(keys: *const [10]B, messages: *align(16) [2]B) void {
    @setRuntimeSafety(false);
    @setEvalBranchQuota(100000);
    const input: *align(16) W = @ptrCast(messages);
    var state = affine(input.*, false);
    for (0..9) |r| state = linear(sbox(state ^ affine(broadcast(keys[r]), false), false), false);
    input.* = affine(state ^ affine(broadcast(keys[9]), false), true);
}
pub fn decrypt(keys: *const [10]B, messages: *align(16) [2]B) void {
    @setRuntimeSafety(false);
    @setEvalBranchQuota(100000);
    const input: *align(16) W = @ptrCast(messages);
    var state = affine(input.*, false);
    for (0..9) |r| state = sbox(linear(state ^ affine(broadcast(keys[9 - r]), false), true), true);
    input.* = affine(state ^ affine(broadcast(keys[0]), false), true);
}

test "pair affine and both substitutions cover every byte in both lanes" {
    if (comptime !supported) return error.SkipZigTest;
    const t = @import("std").testing;
    for (0..256) |x| {
        var input: W = undefined;
        for (0..32) |i| input[i] = @truncate(x + i * 37);
        const a = affine(input, false);
        try t.expectEqual(input, affine(a, true));
        const e = affine(sbox(a, false), true);
        const d = affine(sbox(a, true), true);
        for (0..32) |i| {
            try t.expectEqual(toAes(input[i]), a[i]);
            try t.expectEqual(definitions.pi_table[input[i]], e[i]);
            try t.expectEqual(definitions.pi_inv_table[input[i]], d[i]);
        }
    }
}
test "pair linear independent binary bases in both lanes" {
    if (comptime !supported) return error.SkipZigTest;
    const t = @import("std").testing;
    for (0..2) |lane| for (0..16) |pos| for (0..8) |bit| {
        var input: [2]B = @splat(@splat(0));
        input[lane][pos] = @as(u8, 1) << @intCast(bit);
        const a = affine(@bitCast(input), false);
        const e: [2]B = @bitCast(affine(linear(a, false), true));
        const d: [2]B = @bitCast(affine(linear(a, true), true));
        for (0..2) |i| {
            try t.expectEqual(transitions.l_trans(input[i]), e[i]);
            try t.expectEqual(transitions.l_inv_trans(input[i]), d[i]);
        }
    };
}
test "pair public API arbitrary input keys guards and sixteen-byte offsets" {
    if (comptime !supported) return error.SkipZigTest;
    const std = @import("std");
    const C = @import("kuznechik.zig").Cipher;
    var prng = std.Random.DefaultPrng.init(0xf1e2d3c4);
    const rng = prng.random();
    for (0..10) |ki| {
        var k: definitions.key = undefined;
        rng.bytes(std.mem.asBytes(&k));
        if (ki == 0) k = @splat(0);
        if (ki == 1) k = @splat(255);
        const c = C.init(k);
        try std.testing.expectEqual(@as(usize, 352), @sizeOf(C));
        inline for (.{ false, true }) |inverse| {
            for (0..4) |offset| for (0..64) |_| {
                var data: [8]B align(16) = undefined;
                rng.bytes(std.mem.asBytes(&data));
                var expected = data;
                for (offset..offset + 2) |i| {
                    var a = expected[i];
                    if (inverse) {
                        a ^= c.ik[9];
                        var r: usize = 9;
                        while (r > 0) : (r -= 1) a = transitions.s_inv_trans(transitions.l_inv_trans(a)) ^ c.ik[r - 1];
                    } else {
                        for (0..9) |r| a = transitions.l_trans(transitions.s_trans(a ^ c.ik[r]));
                        a ^= c.ik[9];
                    }
                    expected[i] = a;
                }
                if (inverse) c.decryptBlocks(data[offset..][0..2]) else c.encryptBlocks(data[offset..][0..2]);
                try std.testing.expectEqualDeep(expected, data);
            };
        }
    }
}

test "pair CBC IV2 complete unaligned operations preserve output state and guards" {
    if (comptime !supported) return error.SkipZigTest;
    const std = @import("std");
    const M = @import("kuznechik.zig");
    var prng = std.Random.DefaultPrng.init(0x373829191ab);
    const rng = prng.random();
    for (0..4) |ki| {
        var k: definitions.key = undefined;
        rng.bytes(std.mem.asBytes(&k));
        if (ki == 0) k = @splat(0);
        if (ki == 1) k = @splat(255);
        const c = M.Cipher.init(k);
        var iv: [32]u8 = undefined;
        rng.bytes(&iv);
        for ([_]usize{ 0, 16, 32, 48, 64, 80, 112, 128, 144, 256, 1024 }) |len| {
            for ([_]usize{ 1, 17, 33 }) |off| {
                inline for (.{ false, true }) |inverse| {
                    var data: [1088]u8 = undefined;
                    rng.bytes(&data);
                    var expected = data;
                    var register: [2]B = @bitCast(iv);
                    var head: usize = 0;
                    var at: usize = 0;
                    while (at < len) : (at += 16) {
                        const original: B = data[off + at ..][0..16].*;
                        var a = original;
                        if (inverse) {
                            a ^= c.ik[9];
                            var r: usize = 9;
                            while (r > 0) : (r -= 1) a = transitions.s_inv_trans(transitions.l_inv_trans(a)) ^ c.ik[r - 1];
                            a ^= register[head];
                            register[head] = original;
                        } else {
                            a ^= register[head];
                            for (0..9) |r| a = transitions.l_trans(transitions.s_trans(a ^ c.ik[r]));
                            a ^= c.ik[9];
                            register[head] = a;
                        }
                        head = (head + 1) % 2;
                        expected[off + at ..][0..16].* = a;
                    }
                    var ctx = M.modes.CbcWithIv(2).init(c, iv);
                    if (inverse) try ctx.decrypt(data[off..][0..len]) else try ctx.encrypt(data[off..][0..len]);
                    try std.testing.expectEqualDeep(expected, data);
                    try std.testing.expectEqualDeep(register, ctx.register);
                    try std.testing.expectEqual(head, ctx.head);
                }
            }
        }
    }
}

test "pair residuals after complete bulk chunks preserve guards" {
    if (comptime !supported) return error.SkipZigTest;
    const std = @import("std");
    const C = @import("kuznechik.zig").Cipher;
    var prng = std.Random.DefaultPrng.init(0xf00dbeeffeed);
    const rng = prng.random();
    var k: definitions.key = undefined;
    rng.bytes(std.mem.asBytes(&k));
    const c = C.init(k);
    for ([_]usize{ 66, 130, 194 }) |len| {
        for (0..4) |offset| {
            inline for (.{ false, true }) |inverse| {
                var data: [200]B align(16) = undefined;
                rng.bytes(std.mem.asBytes(&data));
                var expected = data;
                for (expected[offset..][0..len]) |*b| {
                    if (inverse) c.decrypt(b) else c.encrypt(b);
                }
                if (inverse) c.decryptBlocks(data[offset..][0..len]) else c.encryptBlocks(data[offset..][0..len]);
                try std.testing.expectEqualDeep(expected, data);
            }
        }
    }
}
