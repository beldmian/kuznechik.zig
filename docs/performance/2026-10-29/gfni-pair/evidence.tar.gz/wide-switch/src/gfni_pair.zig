//! Control: specialize only the two-block copies, retain the original ZMM kernel.
const gfni = @import("gfni.zig");
const definitions = @import("definitions.zig");
const transitions = @import("transitions.zig");
const B = definitions.block;
// Keep missing-VL profiles on the original dispatch; this is the measured
// profile policy, not an intrinsic requirement of the reused ZMM kernel.
pub const supported = gfni.supported and
    @import("std").Target.x86.featureSetHasAll(@import("builtin").cpu.features, &.{.avx512vl});
pub fn encrypt(keys: *const [10]B, messages: *align(16) [2]B) void {
    var padded: [4]B align(16) = .{ messages[0], messages[1], @splat(0), @splat(0) };
    gfni.encrypt(1, keys, &padded);
    messages.* = padded[0..2].*;
}
pub fn decrypt(keys: *const [10]B, messages: *align(16) [2]B) void {
    var padded: [4]B align(16) = .{ messages[0], messages[1], @splat(0), @splat(0) };
    gfni.decrypt(1, keys, &padded);
    messages.* = padded[0..2].*;
}

test "pair public API arbitrary input keys guards and sixteen-byte offsets" {
    if (comptime !supported) return error.SkipZigTest;
    const std = @import("std");
    const C = @import("kuznechik.zig").Cipher;
    var prng = std.Random.DefaultPrng.init(0xf1e2d3c4);
    const rng = prng.random();
    for (0..10) |ki| {
        var k: definitions.key = undefined;
        rng.bytes(std.mem.asBytes(&k));
        if (ki == 0) k = @splat(0);
        if (ki == 1) k = @splat(255);
        const c = C.init(k);
        try std.testing.expectEqual(@as(usize, 352), @sizeOf(C));
        inline for (.{ false, true }) |inverse| {
            for (0..4) |offset| for (0..64) |_| {
                var data: [8]B align(16) = undefined;
                rng.bytes(std.mem.asBytes(&data));
                var expected = data;
                for (offset..offset + 2) |i| {
                    var a = expected[i];
                    if (inverse) {
                        a ^= c.ik[9];
                        var r: usize = 9;
                        while (r > 0) : (r -= 1) a = transitions.s_inv_trans(transitions.l_inv_trans(a)) ^ c.ik[r - 1];
                    } else {
                        for (0..9) |r| a = transitions.l_trans(transitions.s_trans(a ^ c.ik[r]));
                        a ^= c.ik[9];
                    }
                    expected[i] = a;
                }
                if (inverse) c.decryptBlocks(data[offset..][0..2]) else c.encryptBlocks(data[offset..][0..2]);
                try std.testing.expectEqualDeep(expected, data);
            };
        }
    }
}

test "pair CBC IV2 complete unaligned operations preserve output state and guards" {
    if (comptime !supported) return error.SkipZigTest;
    const std = @import("std");
    const M = @import("kuznechik.zig");
    var prng = std.Random.DefaultPrng.init(0x373829191ab);
    const rng = prng.random();
    for (0..4) |ki| {
        var k: definitions.key = undefined;
        rng.bytes(std.mem.asBytes(&k));
        if (ki == 0) k = @splat(0);
        if (ki == 1) k = @splat(255);
        const c = M.Cipher.init(k);
        var iv: [32]u8 = undefined;
        rng.bytes(&iv);
        for ([_]usize{ 0, 16, 32, 48, 64, 80, 112, 128, 144, 256, 1024 }) |len| {
            for ([_]usize{ 1, 17, 33 }) |off| {
                inline for (.{ false, true }) |inverse| {
                    var data: [1088]u8 = undefined;
                    rng.bytes(&data);
                    var expected = data;
                    var register: [2]B = @bitCast(iv);
                    var head: usize = 0;
                    var at: usize = 0;
                    while (at < len) : (at += 16) {
                        const original: B = data[off + at ..][0..16].*;
                        var a = original;
                        if (inverse) {
                            a ^= c.ik[9];
                            var r: usize = 9;
                            while (r > 0) : (r -= 1) a = transitions.s_inv_trans(transitions.l_inv_trans(a)) ^ c.ik[r - 1];
                            a ^= register[head];
                            register[head] = original;
                        } else {
                            a ^= register[head];
                            for (0..9) |r| a = transitions.l_trans(transitions.s_trans(a ^ c.ik[r]));
                            a ^= c.ik[9];
                            register[head] = a;
                        }
                        head = (head + 1) % 2;
                        expected[off + at ..][0..16].* = a;
                    }
                    var ctx = M.modes.CbcWithIv(2).init(c, iv);
                    if (inverse) try ctx.decrypt(data[off..][0..len]) else try ctx.encrypt(data[off..][0..len]);
                    try std.testing.expectEqualDeep(expected, data);
                    try std.testing.expectEqualDeep(register, ctx.register);
                    try std.testing.expectEqual(head, ctx.head);
                }
            }
        }
    }
}

test "pair residuals after complete bulk chunks preserve guards" {
    if (comptime !supported) return error.SkipZigTest;
    const std = @import("std");
    const C = @import("kuznechik.zig").Cipher;
    var prng = std.Random.DefaultPrng.init(0xf00dbeeffeed);
    const rng = prng.random();
    var k: definitions.key = undefined;
    rng.bytes(std.mem.asBytes(&k));
    const c = C.init(k);
    for ([_]usize{ 66, 130, 194 }) |len| {
        for (0..4) |offset| {
            inline for (.{ false, true }) |inverse| {
                var data: [200]B align(16) = undefined;
                rng.bytes(std.mem.asBytes(&data));
                var expected = data;
                for (expected[offset..][0..len]) |*b| {
                    if (inverse) c.decrypt(b) else c.encrypt(b);
                }
                if (inverse) c.decryptBlocks(data[offset..][0..len]) else c.encryptBlocks(data[offset..][0..len]);
                try std.testing.expectEqualDeep(expected, data);
            }
        }
    }
}
