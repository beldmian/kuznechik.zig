//! Diagonally normalized recursive equal-block circuit:70 constant GFNI maps.
//! One generated graph serves scalar verification and the64-block vector path.
//! See docs/performance/2026-10-29/bitwise-normalization/prepare.py for its exact derivation.
const std = @import("std");
pub const W = @Vector(64, u8);
fn kuzMul(a_in: u8, b_in: u8) u8 {
    var a = a_in;
    var b = b_in;
    var out: u8 = 0;
    for (0..8) |_| {
        if (b & 1 != 0) out ^= a;
        const carry = a & 0x80 != 0;
        a = (a << 1) ^ @as(u8, if (carry) 0xc3 else 0);
        b >>= 1;
    }
    return out;
}
fn matrix(comptime coefficient: u8) u64 {
    @setEvalBranchQuota(1000000);
    var out: u64 = 0;
    for (0..8) |j| {
        var row: u8 = 0;
        for (0..8) |i| row |= ((kuzMul(@as(u8, 1) << @intCast(i), coefficient) >> @intCast(j)) & 1) << @intCast(i);
        out |= @as(u64, row) << @intCast((7 - j) * 8);
    }
    return out;
}
const matrix_pool = blk: {
    @setEvalBranchQuota(10000000);
    var out: [256]u64 = undefined;
    for (0..256) |i| out[i] = matrix(@intCast(i));
    break :blk out;
};
inline fn multiply(comptime T: type, a: T, comptime coefficient: u8) T {
    @setEvalBranchQuota(1000000);
    if (T == u8) return kuzMul(a, coefficient);
    const code = comptime std.fmt.comptimePrint("vgf2p8affineqb $0, {d}(%[m]){{1to8}}, %[a], %[out]", .{@as(usize, coefficient) * 8});
    return asm (code
        : [out] "=v" (-> T),
        : [a] "v" (a),
          [m] "r" (&matrix_pool),
        : .{ .memory = true });
}
inline fn xor3(comptime T: type, a: T, b: T, c: T) T {
    if (T == u8) return a ^ b ^ c;
    return asm ("vpternlogd $0x96, %[c], %[b], %[a]"
        : [out] "=v" (-> T),
        : [a] "0" (a),
          [b] "v" (b),
          [c] "v" (c),
    );
}
pub const row_scale = [16]u8{ 84, 101, 95, 228, 112, 123, 175, 29, 125, 166, 162, 57, 17, 34, 154, 156 };
pub const column_scale = [16]u8{ 182, 247, 1, 63, 255, 1, 200, 130, 222, 16, 229, 45, 150, 160, 14, 235 };
pub const row_inverse = [16]u8{ 252, 11, 6, 202, 189, 138, 184, 35, 238, 231, 180, 174, 163, 176, 178, 40 };
pub const column_inverse = [16]u8{ 179, 89, 1, 147, 203, 1, 26, 217, 18, 181, 254, 205, 140, 39, 161, 236 };
pub inline fn multiplyConstant(a: W, comptime c: u8) W {
    if (c == 0) return @splat(0);
    if (c == 1) return a;
    return multiply(W, a, c);
}
inline fn circuit(comptime T: type, input: [16]T, key: @Vector(16, u8)) [16]T {
    const w17 = input[0] ^ input[8];
    const w18 = input[1] ^ input[9];
    const w19 = input[2] ^ input[10];
    const w20 = input[3] ^ input[11];
    const w21 = input[4] ^ input[12];
    const w22 = input[5] ^ input[13];
    const w23 = input[6] ^ input[14];
    const w24 = input[7] ^ input[15];
    const w25 = w17 ^ w21;
    const w26 = w18 ^ w22;
    const w27 = w19 ^ w23;
    const w28 = w20 ^ w24;
    const w29 = w25 ^ w27;
    const w30 = w26 ^ w28;
    const w31 = w29 ^ w30;
    const w32 = multiply(T, w31, 223);
    const w33 = multiply(T, w29, 135);
    const w34 = w30 ^ w32;
    const w35 = w32 ^ w33;
    const w36 = w27 ^ w28;
    const w37 = multiply(T, w36, 115);
    const w38 = multiply(T, w28, 242);
    const w39 = multiply(T, w27, 253);
    const w40 = w37 ^ w38;
    const w41 = w37 ^ w39;
    const w42 = w25 ^ w26;
    const w43 = multiply(T, w42, 95);
    const w44 = multiply(T, w26, 34);
    const w45 = multiply(T, w25, 192);
    const w46 = w43 ^ w44;
    const w47 = w43 ^ w45;
    const w48 = w34 ^ w40;
    const w49 = w35 ^ w41;
    const w50 = w34 ^ w46;
    const w51 = w35 ^ w47;
    const w52 = w21 ^ w23;
    const w53 = w22 ^ w24;
    const w54 = w52 ^ w53;
    const w55 = multiply(T, w54, 72);
    const w56 = w23 ^ w24;
    const w57 = multiply(T, w56, 94);
    const w58 = multiply(T, w24, 34);
    const w59 = multiply(T, w23, 4);
    const w60 = w57 ^ w58;
    const w61 = w57 ^ w59;
    const w62 = w21 ^ w22;
    const w63 = multiply(T, w62, 116);
    const w64 = multiply(T, w22, 223);
    const w65 = multiply(T, w21, 60);
    const w66 = w63 ^ w64;
    const w67 = w63 ^ w65;
    const w68 = w55 ^ w60;
    const w69 = w55 ^ w61;
    const w70 = w55 ^ w66;
    const w71 = w55 ^ w67;
    const w72 = w17 ^ w19;
    const w73 = w18 ^ w20;
    const w74 = w72 ^ w73;
    const w75 = multiply(T, w74, 205);
    const w76 = multiply(T, w73, 205);
    const w77 = multiply(T, w72, 127);
    const w78 = w75 ^ w76;
    const w79 = w75 ^ w77;
    const w80 = w19 ^ w20;
    const w81 = multiply(T, w80, 223);
    const w82 = multiply(T, w20, 174);
    const w83 = multiply(T, w19, 109);
    const w84 = w81 ^ w82;
    const w85 = w81 ^ w83;
    const w86 = w17 ^ w18;
    const w87 = multiply(T, w86, 140);
    const w88 = multiply(T, w17, 48);
    const w89 = w18 ^ w87;
    const w90 = w87 ^ w88;
    const w91 = w78 ^ w84;
    const w92 = w79 ^ w85;
    const w93 = w78 ^ w89;
    const w94 = w79 ^ w90;
    const w95 = w48 ^ w68;
    const w96 = w49 ^ w69;
    const w97 = w50 ^ w70;
    const w98 = w51 ^ w71;
    const w99 = w48 ^ w91;
    const w100 = w49 ^ w92;
    const w101 = w50 ^ w93;
    const w102 = w51 ^ w94;
    const w103 = input[8] ^ input[12];
    const w104 = input[9] ^ input[13];
    const w105 = input[10] ^ input[14];
    const w106 = input[11] ^ input[15];
    const w107 = w103 ^ w105;
    const w108 = w104 ^ w106;
    const w109 = w107 ^ w108;
    const w110 = multiply(T, w109, 251);
    const w111 = multiply(T, w108, 43);
    const w112 = multiply(T, w107, 225);
    const w113 = w110 ^ w111;
    const w114 = w110 ^ w112;
    const w115 = w105 ^ w106;
    const w116 = multiply(T, w115, 130);
    const w117 = multiply(T, w106, 11);
    const w118 = multiply(T, w105, 172);
    const w119 = w116 ^ w117;
    const w120 = w116 ^ w118;
    const w121 = w103 ^ w104;
    const w122 = multiply(T, w121, 220);
    const w123 = multiply(T, w104, 100);
    const w124 = multiply(T, w103, 194);
    const w125 = w122 ^ w123;
    const w126 = w122 ^ w124;
    const w127 = w113 ^ w119;
    const w128 = w114 ^ w120;
    const w129 = w113 ^ w125;
    const w130 = w114 ^ w126;
    const w131 = input[12] ^ input[14];
    const w132 = input[13] ^ input[15];
    const w133 = w131 ^ w132;
    const w134 = multiply(T, w133, 137);
    const w135 = w132 ^ w134;
    const w136 = input[14] ^ input[15];
    const w137 = multiply(T, w136, 110);
    const w138 = multiply(T, input[15], 255);
    const w139 = multiply(T, input[14], 197);
    const w140 = w137 ^ w138;
    const w141 = w137 ^ w139;
    const w142 = input[12] ^ input[13];
    const w143 = multiply(T, w142, 16);
    const w144 = multiply(T, input[13], 249);
    const w145 = multiply(T, input[12], 95);
    const w146 = w143 ^ w144;
    const w147 = w143 ^ w145;
    const w148 = w135 ^ w140;
    const w149 = w134 ^ w141;
    const w150 = w135 ^ w146;
    const w151 = w134 ^ w147;
    const w152 = input[8] ^ input[10];
    const w153 = input[9] ^ input[11];
    const w154 = w152 ^ w153;
    const w155 = multiply(T, w154, 183);
    const w156 = multiply(T, w152, 47);
    const w157 = w155 ^ w156;
    const w158 = input[10] ^ input[11];
    const w159 = multiply(T, w158, 55);
    const w160 = multiply(T, input[11], 154);
    const w161 = multiply(T, input[10], 242);
    const w162 = w159 ^ w160;
    const w163 = w159 ^ w161;
    const w164 = input[8] ^ input[9];
    const w165 = multiply(T, input[9], 147);
    const w166 = w164 ^ w165;
    const w167 = input[8] ^ w164;
    const w168 = w155 ^ w162;
    const w169 = w157 ^ w163;
    const w170 = w155 ^ w166;
    const w171 = w157 ^ w167;
    const w172 = w127 ^ w148;
    const w173 = w128 ^ w149;
    const w174 = w129 ^ w150;
    const w175 = w130 ^ w151;
    const w176 = w127 ^ w168;
    const w177 = w128 ^ w169;
    const w178 = w129 ^ w170;
    const w179 = w130 ^ w171;
    const w180 = input[0] ^ input[4];
    const w181 = input[1] ^ input[5];
    const w182 = input[2] ^ input[6];
    const w183 = input[3] ^ input[7];
    const w184 = w180 ^ w182;
    const w185 = w181 ^ w183;
    const w187 = multiply(T, w185, 30);
    const w188 = multiply(T, w184, 139);
    const w189 = w182 ^ w183;
    const w190 = multiply(T, w189, 51);
    const w191 = multiply(T, w183, 201);
    const w192 = multiply(T, w182, 94);
    const w193 = w190 ^ w191;
    const w194 = w190 ^ w192;
    const w195 = w180 ^ w181;
    const w196 = multiply(T, w195, 57);
    const w197 = multiply(T, w181, 78);
    const w198 = multiply(T, w180, 228);
    const w199 = w196 ^ w197;
    const w200 = w196 ^ w198;
    const w201 = w187 ^ w193;
    const w202 = w188 ^ w194;
    const w203 = w187 ^ w199;
    const w204 = w188 ^ w200;
    const w205 = input[4] ^ input[6];
    const w206 = input[5] ^ input[7];
    const w207 = w205 ^ w206;
    const w208 = multiply(T, w207, 234);
    const w209 = multiply(T, w206, 105);
    const w210 = multiply(T, w205, 114);
    const w211 = w208 ^ w209;
    const w212 = w208 ^ w210;
    const w213 = input[6] ^ input[7];
    const w214 = multiply(T, input[6], 201);
    const w215 = input[7] ^ w213;
    const w216 = w213 ^ w214;
    const w217 = input[4] ^ input[5];
    const w218 = multiply(T, w217, 27);
    const w219 = multiply(T, input[5], 189);
    const w220 = multiply(T, input[4], 31);
    const w221 = w218 ^ w219;
    const w222 = w218 ^ w220;
    const w223 = w211 ^ w215;
    const w224 = w212 ^ w216;
    const w225 = w211 ^ w221;
    const w226 = w212 ^ w222;
    const w227 = input[0] ^ input[2];
    const w228 = input[1] ^ input[3];
    const w229 = w227 ^ w228;
    const w230 = multiply(T, w229, 181);
    const w231 = multiply(T, w228, 254);
    const w232 = multiply(T, w227, 18);
    const w233 = w230 ^ w231;
    const w234 = w230 ^ w232;
    const w235 = input[2] ^ input[3];
    const w236 = multiply(T, w235, 118);
    const w237 = multiply(T, input[3], 17);
    const w238 = multiply(T, input[2], 179);
    const w239 = w236 ^ w237;
    const w240 = w236 ^ w238;
    const w241 = input[0] ^ input[1];
    const w242 = multiply(T, w241, 95);
    const w243 = multiply(T, input[1], 205);
    const w244 = multiply(T, input[0], 231);
    const w245 = w242 ^ w243;
    const w246 = w242 ^ w244;
    const w247 = w233 ^ w239;
    const w248 = w234 ^ w240;
    const w249 = w233 ^ w245;
    const w250 = w234 ^ w246;
    const w251 = w201 ^ w223;
    const w252 = w202 ^ w224;
    const w253 = w203 ^ w225;
    const w254 = w204 ^ w226;
    const w255 = w201 ^ w247;
    const w256 = w202 ^ w248;
    const w257 = w203 ^ w249;
    const w258 = w204 ^ w250;
    return .{ xor3(T, w95, w172, (if (T == u8) key[0] else @as(T, @splat(key[0])))), xor3(T, w96, w173, (if (T == u8) key[1] else @as(T, @splat(key[1])))), xor3(T, w97, w174, (if (T == u8) key[2] else @as(T, @splat(key[2])))), xor3(T, w98, w175, (if (T == u8) key[3] else @as(T, @splat(key[3])))), xor3(T, w99, w176, (if (T == u8) key[4] else @as(T, @splat(key[4])))), xor3(T, w100, w177, (if (T == u8) key[5] else @as(T, @splat(key[5])))), xor3(T, w101, w178, (if (T == u8) key[6] else @as(T, @splat(key[6])))), xor3(T, w102, w179, (if (T == u8) key[7] else @as(T, @splat(key[7])))), xor3(T, w95, w251, (if (T == u8) key[8] else @as(T, @splat(key[8])))), xor3(T, w96, w252, (if (T == u8) key[9] else @as(T, @splat(key[9])))), xor3(T, w97, w253, (if (T == u8) key[10] else @as(T, @splat(key[10])))), xor3(T, w98, w254, (if (T == u8) key[11] else @as(T, @splat(key[11])))), xor3(T, w99, w255, (if (T == u8) key[12] else @as(T, @splat(key[12])))), xor3(T, w100, w256, (if (T == u8) key[13] else @as(T, @splat(key[13])))), xor3(T, w101, w257, (if (T == u8) key[14] else @as(T, @splat(key[14])))), xor3(T, w102, w258, (if (T == u8) key[15] else @as(T, @splat(key[15])))) };
}
pub inline fn forward(comptime T: type, input: [16]T) [16]T {
    return circuit(T, input, @splat(0));
}
pub inline fn inverse(comptime T: type, input: [16]T) [16]T {
    var rev: [16]T = undefined;
    inline for (0..16) |i| rev[i] = input[15 - i];
    const y = forward(T, rev);
    inline for (0..16) |i| rev[i] = y[15 - i];
    return rev;
}
pub inline fn forwardSeeded(input: [16]W, key: @Vector(16, u8)) [16]W {
    return circuit(W, input, key);
}
pub inline fn inverseSeeded(input: [16]W, key: @Vector(16, u8)) [16]W {
    var rev: [16]W = undefined;
    var rk: @Vector(16, u8) = undefined;
    inline for (0..16) |i| {
        rev[i] = input[15 - i];
        rk[i] = key[15 - i];
    }
    const y = forwardSeeded(rev, rk);
    inline for (0..16) |i| rev[i] = y[15 - i];
    return rev;
}
